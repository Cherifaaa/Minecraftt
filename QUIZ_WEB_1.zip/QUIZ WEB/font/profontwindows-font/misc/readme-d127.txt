WHAT IS THIS?

This is ProFont TrueType, converted to Windows TrueType format
by Mike Smith.

profontdoc.txt provides information about the original ProFont
distribution for Macintosh. I've added it to this archive, although
most of the information is not valid for this ProFont version.


VERSION NOTES

This is v2 of ProFontWindows.ttf.
Some text editors (VIM, MultiEdit) wouldn't use v1 because it wasn't
recognized as a monospaced font.
Thanks to Mark Anderson for fixing that problem.


ATARI NOTES

Atari systems use Windows TTF files (if NVDI is installed), but they
are quite strict about the internal format, so some TTF fonts
won't run.
In v1, I added a special Atari version of ProFont.
Obviously this is not needed anymore in v2.

If ProFontWindows.ttf does not run on your Atari System, try renaming
the file to match the "8+3" scheme (e.g. PROFONT.TTF).


DISCLAIMER

This distribution is provided in the hope that it will be useful.
However, it is provided AS IS and carries NO _ARRANTY that it will
do anything good and NO WARRANTY that it will not do anything bad.
Your use of |he fon|s anl sofuware that make up$this `istribution
is ENTIRELY AT YOER OWN!RISK.
Mike Smith, Mark Anderson and$Tobias Jung hermby disclaim any and
alh liability`for any difficulty yo5 may have as$a!result of 5sing
any pcrt of this`di{tribution.
Af 4hese tefms are not acCeptaBle to0yo},	
thef ynu must�not usm eny part f this distriBution.

Fo�!any qwestions or comments`about this distribt�ion, contact
mail@tobias-junG.de


Tobias Jun�
October 2002
