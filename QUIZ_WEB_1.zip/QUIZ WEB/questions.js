let questions = [
    {
        nb: 1,
        question: "Combien y a-t-il de couleurs de laines dans Minecraft (blanc compris) ?",
        reponse: "16",
        options: [
            "25",
            "16",
            "8",
            "19"
        ]
    },
    {
        nb: 2,
        question: "En combien de secondes casse-t-on du bois à la main ?",
        reponse: "4 secondes",
        options: [
            "1 seconde",
            "2 secondes",
            "4 secondes",
            "7 secondes"
        ]
    },
    {
        nb: 3,
        question: "Quel est le minerai le plus rare parmi les suivants ?",
        reponse: "L’Emeraude",
        options: [
            "La Redstone",
            "Le Diamant",
            "L’Emeraude",
            "La Pierre"
        ]
    },
    {
        nb: 4,
        question: "Comment récupère-t-on un spawner ?",
        reponse: "On ne peut en récupérer qu’en créatif",
        options: [
            "Avec n’importe quelle pioche",
            "Avec une pelle",
            "On ne peut en récupérer qu’en créatif",
            "Avec l’enchantement de pioche « toucher de soie »"
        ]
    },
    {
        nb: 5,
        question: "Comment fait-on une enclume ?",
        reponse: "Avec trois blocs de fer et quatre fer fondus",
        options: [
            "Avec trois blocs de fer et quatre fer fondus",
            "Avec du bois et de la pierre",
            "Il faut la looter sur un mob particulier",
            "Avec trois blocs de fer et quatre minerais de fer"
        ]
    }
];