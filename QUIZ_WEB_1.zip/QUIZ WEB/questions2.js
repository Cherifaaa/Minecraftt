let questions = [
    {
        nb: 1,
        question: "Combien de dégâts fait l'épée en diamant ?",
        reponse: "7",
        options: [
            "10",
            "7",
            "5",
            "12"
        ]
    },
    {
        nb: 2,
        question: "Comment les speedrunners utilisent-ils le lit?",
        reponse: "Pour faire exploser l'Ender Dragon",
        options: [
            "Pour sauter plus haut ",
            "Pour dormir ",
            "Pour faire exploser l'Ender Dragon",
            "Pour taper les mobs de plus loin"
        ]
    },
    {
        nb: 3,
        question: "Les chauves-souris sont agressives sur Minecraft",
        reponse: "Faux",
        options: [
            "Vrai",
            "Faux"
        ]
    },
    {
        nb: 4,
        question: "Quel est le principal mob présent dans les forteresses du Nether ?",
        reponse: "Le Blaze",
        options: [
            "Le Piglin",
            "Le Blaze",
            "L’Enderman",
            "L’Arpenteur"
        ]
    },
    {
        nb: 5,
        question: "Dans quelle circonstance un Enderman va se mettre à vous attaquer ?",
        reponse: "Si vous le regardez dans les yeux",
        options: [
            "Si vous êtes autour de lui",
            "Si vous allez dans l’Ender",
            "Si vous le regardez dans les yeux",
            "Si vous leur lancez des projectiles"
        ]
    }
];


