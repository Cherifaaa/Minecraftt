let questions = [
    {
        nb: 1,
        question: "En quelle année a été créé Minecraft ? ",
        reponse: "2009",
        options: [
            "2008",
            "2009",
            "2010",
            "2011"
        ]
    },
    {
        nb: 2,
        question: "En quelle année Mojang s’est-il fait racheter par Microsoft ? ",
        reponse: "2014",
        options: [
            "2012 ",
            "2013 ",
            "2014",
            "2015"
        ]
    },
    {
        nb: 3,
        question: "Quelles sont les différences majeures entre les versions Java et Bedrock ? (Réponses multiples)",
        reponse: "Bedrock permet de jouer en Cross-Play",
        options: [
            "Java offre de meilleures performances",
            "Bedrock permet de jouer en Cross-Play",
            "Java possede moins de mods",
            "Java est la version développée par Microsoft"

        ]
    },
    {
        nb: 4,
        question: "Qui est C418 ?",
        reponse: "Le musicien qui a fait les musiques et sons d’ambiances du jeu",
        options: [
            "Un développeur chez Mojang",
            "Le frère de Notch",
            "L’actuel dirigeant de Mojang",
            "Le musicien qui a fait les musiques et sons d’ambiances du jeu"
        ]
    },
    {
        nb: 5,
        question: "Dans quelle version est apparu pour la première fois le Wither ? ",
        reponse: "1.4.2",
        options: [
            "1.3.5",
            "1.4.2",
            "1.5.1",
            "1.6.3"
        ]
    }
];

