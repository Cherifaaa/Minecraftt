let questions = [
    {
        nb: 1,
        question: "Quand on mange un Chorus, quel effet a-t-on ?",
        reponse: "On se téléporte",
        options: [
            "L’effet poison",
            "L’effet lévitation",
            "On se téléporte"
        ]
    },
    {
        nb: 2,
        question: "Depuis quand est-il indispensable de se nourrir sur Minecraft ?",
        reponse: "La Beta 1.8",
        options: [
            "L’alpha 1.8",
            "La Beta 1.7.8",
            "La Beta 1.8"
        ]
    },
    {
        nb: 3,
        question: "Quelles sont les différentes utilités de l’œil d’araignée ?",
        reponse: "Il peut être mangé, peut être crafté et utilisé pour les potions",
        options: [
            "Il peut être mangé et peut être utilisé pour les potions",
            "Il peut être mangé, peut être crafté et utilisé pour les potions",
            "Il peut être mangé et crafté"
        ]
    },
    {
        nb: 4,
        question: "Parmi ces aliments, lequel n’existe pas ?",
        reponse: "La poire",
        options: [
            "La poire",
            "La tarte à la citrouille",
            "La pomme de terre toxique"
        ]
    },
    {
        nb: 5,
        question: "Quelle est la probabilité que l’utilisation d’une perle de l’Ender fasse spawn un Endermite ?",
        reponse: "5%",
        options: [
            "3%",
            "4.5%",
            "5%"
        ]
    }
];

